import os
import asyncio
import logging
from io import BytesIO

from dotenv import load_dotenv
from playwright.async_api import async_playwright, TimeoutError as PlaywrightTimeout
from telegram import Update
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    ConversationHandler,
    ContextTypes,
    filters,
)

load_dotenv()

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)

WAITING_URL, WAITING_LASTNAME, WAITING_FIRSTNAME, WAITING_CLASS, WAITING_AUTH = range(5)


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    await _cleanup_browser(context)
    await update.message.reply_text("Введите URL страницы с тестом")
    return WAITING_URL


async def receive_url(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    url = update.message.text.strip()
    context.user_data["url"] = url
    await update.message.reply_text("Введите фамилию:")
    return WAITING_LASTNAME

async def receive_lastname(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    context.user_data["lastname"] = update.message.text.strip()
    await update.message.reply_text("Введите имя:")
    return WAITING_FIRSTNAME

async def receive_firstname(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    context.user_data["firstname"] = update.message.text.strip()
    await update.message.reply_text("Введите класс (например, 10):")
    return WAITING_CLASS

async def receive_class(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    context.user_data["classTxt"] = update.message.text.strip()
    url = context.user_data.get("url")

    await update.message.reply_text("Открываю страницу, ищу QR-код...")

    try:
        playwright = await async_playwright().start()
        browser = await playwright.chromium.launch(
            headless=True,
            args=[
                "--no-sandbox",
                "--disable-setuid-sandbox",
                "--disable-dev-shm-usage",
                "--disable-blink-features=AutomationControlled",
            ],
        )
        ctx = await browser.new_context(
            user_agent=(
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/122.0.0.0 Safari/537.36"
            ),
            viewport={"width": 1280, "height": 800},
            locale="ru-RU",
        )
        page = await ctx.new_page()
        # Скрываем признаки автоматизации
        await page.add_init_script(
            "Object.defineProperty(navigator, 'webdriver', {get: () => undefined})"
        )

        context.user_data["playwright"] = playwright
        context.user_data["browser"] = browser
        context.user_data["ctx"] = ctx
        context.user_data["page"] = page

        await page.goto(url, timeout=45_000, wait_until="domcontentloaded")
        
        if "videouroki.net/tests/" in url:
            # Заполняем форму
            try:
                await page.fill('input[name="lastname"]', context.user_data.get("lastname", ""))
                await page.fill('input[name="firstname"]', context.user_data.get("firstname", ""))
                await page.fill('input[name="classTxt"]', context.user_data.get("classTxt", ""))
                await page.click('input[value="Начать тест"]')
                await page.wait_for_timeout(3000)
                
                # Ищем текст на странице
                texts = await page.locator(".test-box, .question-text, .test-question, strong, p").all_inner_texts()
                
                questions = []
                for t in texts:
                    t = t.strip()
                    if t and len(t) > 5 and t not in questions:
                        questions.append(t)
                        
                res_text = "\n\n".join(questions)
                if not res_text:
                    res_text = "Не удалось найти вопросы, возможно страница не загрузилась или тест защищен."
                    
                if len(res_text) > 4000:
                    res_text = res_text[:4000] + "..."
                    
                await update.message.reply_text(f"Тест открыт! Вот что есть на странице:\n\n{res_text}")
                
            except Exception as e:
                await update.message.reply_text(f"Ошибка при заполнении формы: {e}")
                
            # Оставляем браузер открытым, если нужно
            return ConversationHandler.END

        # Для других сайтов - логика QR-кода
        try:
            await page.wait_for_selector("img, canvas", timeout=15_000)
        except Exception:
            pass

        qr_image_data = await _find_qr_image(page)

        if qr_image_data is None:
            qr_image_data = await page.screenshot(full_page=False)
            caption = "QR-код не найден — скриншот страницы.\nОтсканируйте QR-код для авторизации"
        else:
            caption = "Отсканируйте этот QR-код для авторизации"

        await update.message.reply_photo(
            photo=BytesIO(qr_image_data),
            caption=caption,
        )
        await update.message.reply_text(
            "Жду подтверждения авторизации. Когда войдёте — отправьте /authorized"
        )
        return WAITING_AUTH

    except PlaywrightTimeout:
        await update.message.reply_text(
            "⚠️ Таймаут: страница не загрузилась за 45 секунд. Проверьте URL и попробуйте снова /start"
        )
        await _cleanup_browser(context)
        return ConversationHandler.END

    except Exception as e:
        logger.exception("Ошибка при открытии страницы")
        await update.message.reply_text(
            f"❌ Ошибка при открытии страницы: {e}\n\nПопробуйте снова /start"
        )
        await _cleanup_browser(context)
        return ConversationHandler.END


async def authorized(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    await update.message.reply_text("✅ Авторизация принята! Можно продолжать.")
    # Браузер остаётся открытым для дальнейшей работы с тестом
    return ConversationHandler.END


async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    await _cleanup_browser(context)
    await update.message.reply_text("Сессия сброшена. Для начала отправьте /start")
    return ConversationHandler.END


async def _find_qr_image(page) -> bytes | None:
    """
    Ищет QR-код на странице:
    1. img с src содержащим 'qr'
    2. img с alt/class содержащим 'qr'
    3. canvas-элемент (QR часто рендерится через canvas)
    Возвращает bytes изображения или None.
    """
    # Ищем <img> похожий на QR по атрибутам
    selectors = [
        "img[src*='qr' i]",
        "img[alt*='qr' i]",
        "img[class*='qr' i]",
        "img[id*='qr' i]",
        "canvas[class*='qr' i]",
        "canvas[id*='qr' i]",
    ]
    for selector in selectors:
        element = await page.query_selector(selector)
        if element:
            try:
                return await element.screenshot()
            except Exception:
                continue

    # Если ничего не нашли — берём первый заметный canvas
    canvas = await page.query_selector("canvas")
    if canvas:
        try:
            return await canvas.screenshot()
        except Exception:
            pass

    return None


async def _cleanup_browser(context: ContextTypes.DEFAULT_TYPE):
    """Закрывает browser и playwright если они открыты."""
    browser = context.user_data.pop("browser", None)
    playwright = context.user_data.pop("playwright", None)
    context.user_data.pop("ctx", None)
    context.user_data.pop("page", None)

    if browser:
        try:
            await browser.close()
        except Exception:
            pass
    if playwright:
        try:
            await playwright.stop()
        except Exception:
            pass


def main():
    token = os.getenv("TELEGRAM_BOT_TOKEN")
    if not token:
        raise RuntimeError("TELEGRAM_BOT_TOKEN не задан в .env")

    app = Application.builder().token(token).build()

    conv_handler = ConversationHandler(
        entry_points=[CommandHandler("start", start)],
        states={
            WAITING_URL: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, receive_url)
            ],
            WAITING_LASTNAME: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, receive_lastname)
            ],
            WAITING_FIRSTNAME: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, receive_firstname)
            ],
            WAITING_CLASS: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, receive_class)
            ],
            WAITING_AUTH: [
                CommandHandler("authorized", authorized),
            ],
        },
        fallbacks=[CommandHandler("cancel", cancel)],
    )

    app.add_handler(conv_handler)

    logger.info("Бот запущен")
    app.run_polling()


if __name__ == "__main__":
    main()
